# As requested, at link below, for original flagpack. Inclusion for same reason: Historical accuracy and "early rocketry RP" in game.
https://www.reddit.com/r/KerbalSpaceProgram/comments/1evabe/i_made_an_assortment_of_realworld_and_fictional/ca47lcx/

I have no love, or agreement, for/with Nazi's or their beliefs!
# No offence intended, please feel free to delete.