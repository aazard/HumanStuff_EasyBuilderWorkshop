pdn-gmic

Description
------------

A Paint.NET Effect that provides integration with G'MIC-Qt.

Some icons are from or based on those in the Fugue icon set by Yusuke Kamiyamane (http://p.yusukekamiyamane.com/).

For more details, or to report bugs, please refer to the website:

  https://github.com/0xC0000054/pdn-gmic

Installation
-------------

1. Close Paint.NET.
2. Place Gmic.dll and the gmic folder in the Paint.NET Effects folder which is usually located in one the following locations depending on the Paint.NET version you have installed.

  Classic: C:\Program Files\Paint.NET\Effects
  Microsoft Store: Documents\paint.net App Files\Effects

3. Restart Paint.NET.
4. The plug-in will now be available as the G'MIC-Qt menu item in the Advanced category of the Paint.NET Effects menu.

A copy of Paint.NET can be obtained from the official website.
  http://www.getpaint.net/

Licensing 
----------

This project is licensed under the terms of the GNU General Public License version 3.0.   
See License.txt for more information.


