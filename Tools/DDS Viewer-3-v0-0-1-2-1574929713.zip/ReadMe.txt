DDS Viewer v0.0.1.2 - View and Save's image files.

Supported DDS pixel formats
---------------------------
* 8888
* 888
* 565
* 555
* 1555
* 4444
* DXT1/A
* DXT3
* DXT5
* DXT5_NM
* V8U8
* x8 ( G8, B8 not tested yet )
* R16F
* G16R16F
* A16B16G16R16F
* R32F
* G32R32F
* A32B32G32R32F
* ATI1N, ATI2N
* G16R16

Supported map types
-------------------
* 2D
* Volume

Installation
-----------
Copy "DDS Viewer.exe" and "DDS Viewer.exe.config" to a permanent destination (e.g. C:\DDS Viewer\ in my case)

To associate ".dds" files to DDS Viewer :
- right click on any DDS file
- select "Open With"
- select "Choose another app..."
- scroll down to the bottom and click on "More apps"
- scroll down to the bottom again and click on "Look for another app on this computer" and find the DDS Viewer app
- click on "Open" button
- check "Always use this app to open .dds files"

How to use DDS Viewer
--------------
The fastest way of using DDS Viewer is to associate it with DDS files.
Then, simply double-click or press enter on any DDS file to view it.
Another way is to use Drag&Drop or the good old "File->Open..."
By default, the image will be modulated by it's alpha channel ( if there is one ).
If you want to disable that function, click on Options->Alpha Channel.
Background grid is light by default ( can be changed ), in Options->Grid (Light/Dark).
You can browse through all DDS files in the same folder by the mouse wheel rotation..
By default, the image sizemode is set to Zoom. You can change it in the main menu, with the drop down list.
You can flip a image by clicking on Flip Image in Options->Flip Image.

Control/Options overview
---------------------
Open -> Open's most common images - dds, png, bmp, jpg.
Save As -> Save's most common images - dds, png, bmp, jpg. 
Mouse Wheel -> previous/next picture
Alpha Channel -> show/hide alpha channel. Use alpha to blend.
Flip Image -> flips image 180 degrees.
Grid (Light/Dark) -> changes the background image to light or dark. 

Status bar information
----------------------
Format - pixel format of the current DDS file
Height - height of image
Width - width of image
MipMap - current mipmap / mipmap count

Special Thanks
--------------
micolous/andburn for DDSReader Class.
Nvidia for nvdxt api.

!! Any suggestions will be appreciated. !!